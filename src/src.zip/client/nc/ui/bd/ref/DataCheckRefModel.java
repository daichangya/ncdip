package nc.ui.bd.ref;

public class DataCheckRefModel extends AbstractRefModel{
	@Override
	public int getDefaultFieldCount() {
		// TODO Auto-generated method stub
		return 4;
	}
	public String newWherePart="";
    public DataCheckRefModel(){
    	super();
    }

	@Override
	public String[] getFieldCode() {
		// TODO Auto-generated method stub
		return new String[]{"dip_datacheckregist.code","dip_datacheckregist.name","dip_datacheckregist.type","dip_datacheckregist.implementss"};
	}

	@Override
	public String[] getFieldName() {
		// TODO Auto-generated method stub
		return new String[]{"����","����","У������","ʵ����"};
	}

	@Override
	public String[] getHiddenFieldCode() {
		// TODO Auto-generated method stub
		return new String[]{"dip_datacheckregist.pk_dip_datacheckregist"};
	}

	@Override
	public String getPkFieldCode() {
		// TODO Auto-generated method stub
		return "dip_datacheckregist.pk_dip_datacheckregist";
	}

	@Override
	public String getRefTitle() {
		// TODO Auto-generated method stub
		return "����У��";
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return "dip_datacheckregist";
	}

	@Override
	public String getWherePart() {
		// TODO Auto-generated method stub
		return super.getWherePart() ;
	}
	@Override
	public void addWherePart(String newWherePart) {
		// TODO Auto-generated method stub
	
		super.addWherePart(newWherePart);
	}
}
