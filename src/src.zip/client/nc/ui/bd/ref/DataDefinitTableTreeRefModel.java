package nc.ui.bd.ref;

public class DataDefinitTableTreeRefModel extends AbstractRefGridTreeModel{


	
	public DataDefinitTableTreeRefModel(){
		setRefNodeName( );
	}
	public void setRefNodeName(){
		setRefTitle("���ݶ����");
			setRootName("���ݶ���");
			setClassFieldCode(new String[]{"syscode","sysname","pk_datadefinit_h","pk_xt","pk_sysregister_h","iscreatetab","isfolder"});
			setClassTableName("v_dip_sysdefinittree");
			setClassWherePart(" isfolder='Y'");
			setFatherField("pk_sysregister_h");
			setChildField("pk_datadefinit_h");
			setClassJoinField("pk_datadefinit_h");
			setClassDefaultFieldCount(2);
			
			setDocJoinField("pk_sysregister_h");
			setFieldCode(new String[]{"syscode","sysname","memorytable","memorytype","tabsoucetype"});
			setFieldName(new String[]{"����","����","�洢����","�洢����","����Դ����"});
			setTableName("v_dip_sysdefinittree");
			setHiddenFieldCode(new String[]{"pk_datadefinit_h"});
			setPkFieldCode("pk_datadefinit_h");
			setWherePart(" iscreatetab='Y' ");
			setDefaultFieldCount(getFieldCode().length);
			
		}
//	}

}
