package nc.ui.bd.ref;
/*
 * ϵͳע�����
 */
public class SysRegisterRefModel extends AbstractRefModel {

	public SysRegisterRefModel(){
		super();
	}
	@Override
	public String[] getHiddenFieldCode() {
		// TODO Auto-generated method stub
		return new String[]{"dip_sysregister_b.pk_sysregister_b"};
	}

	@Override
	public String getRefTitle() {
		// TODO Auto-generated method stub
		return "ϵͳע��ֲ���ʶ";
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		String sql="dip_sysregister_b inner join dip_sysregister_h on dip_sysregister_b.pk_sysregister_h=dip_sysregister_h.pk_sysregister_h";
		return sql;
	}

	@Override
	public String getWherePart() {
		// TODO Auto-generated method stub
		
		return super.getWherePart();
	}
	@Override
	public String[] getFieldCode() {
		// TODO Auto-generated method stub
		return new String[]{"dip_sysregister_b.sitename","dip_sysregister_b.sitecode"};
	}
	@Override
	public String[] getFieldName() {
		// TODO Auto-generated method stub
		return new String[]{"�ֲ�վ������","�ֲ�վ�����"};
	}

	//�趨�����ֶΣ�������getHiddenFieldCode��setFieldCode���趨
	@Override
	public String getPkFieldCode() {
		// TODO Auto-generated method stub
		return "dip_sysregister_b.pk_sysregister_b" ;
	}
	@Override
	public void addWherePart(String newWherePart) {
		// TODO Auto-generated method stub
	
		super.addWherePart(newWherePart);
	}
	
}
