package nc.ui.bd.ref;
/**
 * �������̲�����
 * @author Administrator
 *
 */
public class DataLCRefModel extends AbstractRefModel{
	public DataLCRefModel(){
		super();
	}
	
	@Override
	public String[] getFieldCode() {
		// TODO Auto-generated method stub
		return new String[]{"v_dip_sjlc.tcode","v_dip_sjlc.tname","v_dip_sjlc.typename"};
	}
	@Override
	public String[] getFieldName() {
		// TODO Auto-generated method stub
		return new String[]{"����","����","��������"};
	}
	@Override
	public String[] getHiddenFieldCode() {
		// TODO Auto-generated method stub
		return new String[]{"v_dip_sjlc.hpk"};
	}

	@Override
	public String getPkFieldCode() {
		// TODO Auto-generated method stub
		return "v_dip_sjlc.hpk";
	}

	@Override
	public String getRefTitle() {
		// TODO Auto-generated method stub
		return "���ñ��ֶ�";
	}

	@Override
	public String getTableName() {
		// TODO Auto-generated method stub
		return "v_dip_sjlc";
	}

	@Override
	public String getWherePart() {
		// TODO Auto-generated method stub
		return super.getWherePart();
	}
	@Override
	public void addWherePart(String newWherePart) {
		// TODO Auto-generated method stub
	
		super.addWherePart(newWherePart);
	}

	@Override
	public int getDefaultFieldCount() {
		// TODO Auto-generated method stub
		return 3;
	}
    
}
