package nc.ui.dip.dateprocess;


import nc.ui.trade.card.CardEventHandler;

public class DateProcessClientUI extends AbstractDateProcessClientUI{
	/**
	 * 
	 */
	public DateProcessClientUI(){
		super();
		this.getBillCardPanel().getBillTable().setColumnSelectionAllowed(false);
	}
	private static final long serialVersionUID = 1L;
	
	
	protected CardEventHandler createEventHandler() {
		return new MyEventHandler(this, getUIControl());
	}

//	public void setBodySpecialData(CircularlyAccessibleValueObject[] vos)
//	throws Exception {}
//
//	protected void setHeadSpecialData(CircularlyAccessibleValueObject vo,
//			int intRow) throws Exception {}
//
//	protected void setTotalHeadSpecialData(CircularlyAccessibleValueObject[] vos)
//	throws Exception {	}

	/**
	 * �޸Ĵ˷�����ʼ��ģ��ؼ�����
	 */
	protected void initSelfData() {	}

	public void setDefaultData() throws Exception {
	}

	public String getRefBillType() {
		return null;
	}


}
