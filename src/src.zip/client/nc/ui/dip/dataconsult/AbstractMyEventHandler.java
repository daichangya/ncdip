package nc.ui.dip.dataconsult;

import nc.ui.trade.bill.IListController;
import nc.ui.trade.list.BillListUI;
import nc.ui.trade.list.ListEventHandler;

public class AbstractMyEventHandler extends ListEventHandler {

    public AbstractMyEventHandler(BillListUI billUI, IListController control){
	super(billUI,control);		
}

protected void onBoElse(int intBtn) throws Exception {
	     	}


}
