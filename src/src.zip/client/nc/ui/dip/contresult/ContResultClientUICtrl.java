package nc.ui.dip.contresult;

import nc.ui.trade.bill.ICardController;
import nc.ui.trade.bill.ISingleController;
import nc.ui.trade.button.IBillButton;


/**
 * <b> �ڴ˴���Ҫ��������Ĺ��� </b>
 *
 * <p>
 *     �ڴ˴����Ӵ����������Ϣ
 * </p>
 *
 * Create on 2006-4-6 16:00:51
 *
 * @author authorName
 * @version tempProject version
 */

public class ContResultClientUICtrl implements ICardController, ISingleController{


	 public ContResultClientUICtrl()
	    {
	    }

	    public String[] getCardBodyHideCol()
	    {
	        return null;
	    }

	    public int[] getCardButtonAry()
	    {
	    	return new int[]{
	 			  IBillButton.Save,
	 			 IBillButton.Edit,
	 			  IBillButton.Delete,
			};
	    }

	    public boolean isShowCardRowNo()
	    {
	        return true;
	    }

	    public boolean isShowCardTotal()
	    {
	        return false;
	    }

	    public String getBillType()
	    {
	        return "H4H7H1";
	    }

	    public String[] getBillVoName()
	    {
	        return (new String[] {
	         nc.vo.trade.pub.HYBillVO.class.getName(),
	         nc.vo.dip.procondition.DipProconditionVO.class.getName(),
	         nc.vo.dip.procondition.DipProconditionVO.class.getName()
	        });
	    	
	    }

	    public String getBodyCondition()
	    {
	        return null;
	    }

	    public String getBodyZYXKey()
	    {
	        return null;
	    }

	    public int getBusinessActionType()
	    {
	        return 1;
	    }

	    public String getChildPkField()
	    {
	        return "pk_procondition";
	    }

	    public String getHeadZYXKey()
	    {
	        return null;
	    }

	    public String getPkField()
	    {
	        return "pk_procondition";
	    }

	    public Boolean isEditInGoing()
	        throws Exception
	    {
	        return null;
	    }

	    public boolean isExistBillStatus()
	    {
	        return false;
	    }

	    public boolean isLoadCardFormula()
	    {
	        return false;
	    }

	    public boolean isSingleDetail()
	    {
	        return true;
	    }
}
