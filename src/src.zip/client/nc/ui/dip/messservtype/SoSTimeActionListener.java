package nc.ui.dip.messservtype;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import nc.ui.dip.warningset.WarningSetClientUI;

public class SoSTimeActionListener implements ActionListener {
	MessServTypeClientUI clientui;
	public SoSTimeActionListener(MessServTypeClientUI clientui){
		super();
		this.clientui=clientui;
	}
	public void actionPerformed(ActionEvent arg0) {
		clientui.onBoTimeSet();
	}

}
