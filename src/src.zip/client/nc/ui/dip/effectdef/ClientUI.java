package nc.ui.dip.effectdef;

//import nc.ui.jyprj.effectdef.MyEventHandler;S
import nc.ui.bd.ref.DataDefinitbRefModel;
import nc.ui.pub.ButtonObject;
import nc.ui.pub.beans.UIRefPane;
import nc.ui.trade.business.HYPubBO_Client;
import nc.ui.trade.card.CardEventHandler;
import nc.uif.pub.exception.UifException;
import nc.util.dip.sj.SJUtil;
import nc.vo.dip.datachange.DipDatachangeHVO;
import nc.vo.dip.effectdef.CdSbodyVO;

/**
 * 
 * <P>
 * <B>��Ƭ�͵�����UI��</B>
 * </P>
 * <P>
 * ����˵��: <BR>
 * �������ṩ���ӡ���ѯ���޸ġ�ɾ�����ܡ�
 * 
 * ע��:
 * ��MyEventHandler���б�����дprocessNewBodyVO()����
 * ��ClientUICtrl���п����޸�getBodyCondition()����,Ϊ��ѯ����Ĭ������
 * ���Ҫ�ڵ��ݱ����ҳ�治ˢ�£������²�ѯ���ݣ�����ClientUICheckRuleGetter�̳�IRetCurrentDataAfterSave�ӿ�
 * 
 * @author �α�
 * @version 1.0
 * @date 2008-3-26
 */
public class ClientUI extends AbstractClientUI {
	String hpk;

	/** �ֶ����� */
	private static final long serialVersionUID = 3899425417611651215L;
	public void initdef(String hpk,boolean flag){
//		��̬�Զ������
		DipDatachangeHVO hvo=null;
		try {
			hvo = (DipDatachangeHVO) HYPubBO_Client.queryByPrimaryKey(DipDatachangeHVO.class, hpk);
			//�����ĸ��ֶ��ж�Ҫ���յ����ĸ���
			String pk_def=hvo.busidata;
			//��������ĸ��ֶ����˲���
			UIRefPane pane=(UIRefPane) this.getBillCardPanel().getBodyItem("ys").getComponent();
			DataDefinitbRefModel ref=new DataDefinitbRefModel();
			ref.addWherePart("and dip_datadefinit_h.pk_datadefinit_h='"+pk_def+"' and nvl(dip_datadefinit_h.dr,0)=0");
			pane.setRefInputType(1 /** ����*/);
			pane.setRefModel(ref);
		} catch (UifException e1) {
			e1.printStackTrace();
		}

		int isEffect;
		if(flag){
			isEffect=1;
		}else{
			isEffect=2;
		}
		this.hpk=hpk;
		try {
			if(hpk!=null){
				CdSbodyVO[] vo=(CdSbodyVO[]) HYPubBO_Client.queryByCondition(CdSbodyVO.class, "dip_datachange_h='"+hpk+"' and flag="+isEffect);
				if(SJUtil.isNull(vo)||vo.length==0){
					for(int i=1;i<9;i++){
						getBillCardPanel().getBillModel().addLine();
						if(i==1){
							getBillCardPanel().setBodyValueAt("affect", i-1, "effectname");
						}else{

							getBillCardPanel().setBodyValueAt("affect"+i, i-1, "effectname");
						}
						getBillCardPanel().setBodyValueAt("Ӱ������"+i, i-1, "effect");
						getBillCardPanel().setBodyValueAt(isEffect, i-1, "flag");
						getBillCardPanel().setBodyValueAt(hpk, i-1, "dip_datachange_h");
					}
				}else{

					for(int i=1;i<9;i++){
						getBillCardPanel().getBillModel().addLine();
					}
					for(int i=0;i<vo.length;i++){
						vo[i].setEffect("Ӱ������"+(i+1));
						getBillCardPanel().getBillModel().setBodyRowVO(vo[i],i);
					}
					getBillCardPanel().getBillModel().execLoadFormula();
				}
			}
		} catch (UifException e) {
			e.printStackTrace();
		}

	}

	protected CardEventHandler createEventHandler() {
		return new MyEventHandler(this, getUIControl());
	}

//	@Override
//	public void windowClosed(WindowEvent arg0) {
//	// TODO Auto-generated method stub
////	super.windowClosed(arg0);
//	}


	public String getRefBillType() {
		return null;
	}


	/**
	 * �޸Ĵ˷�����ʼ��ģ��ؼ�����
	 */
	protected void initSelfData() {


		//getButtonManager().getButton(IBillButton.Edit).setEnabled(true);
	}
	public void onButtonAction(ButtonObject bo)throws Exception
	{
		((MyEventHandler)this.getCardEventHandler()).onButtonAction(bo);

	}
	public void setDefaultData() throws Exception {
	}
//	public void init(MyBillVO vo,boolean isadd){
//	onButtonClicked(getButtonManager().getButton(IBillButton.Card));
//	CdSbodyVO hvo=null;
//	if(isadd){
//	//hvo=(CdSbodyVO) vo.getParentVO();
//	//hvo.setEffectname("Ӱ����������");
////	hvo.setCondition("��������д����");
////	hvo.setIsnotwarning("��");
////	hvo.setIsnottiming("��ʱ");
////	((MyEventHandler)getManageEventHandler()).lodDefaultVo(new SuperVO[]{hvo});

//	}else{
//	getButtonManager().getButton(IBillButton.Edit).setEnabled(true);
////	((MyEventHandler)getManageEventHandler()).lodDefaultVo(new SuperVO[]{(SuperVO) vo.getParentVO()});
//	}

//	try {
//	updateBtnStateByCurrentVO();
//	} catch (Exception e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//	}
//	if(isadd){

//	onButtonClicked(getButtonManager().getButton(IBillButton.Add));
//	getBillCardPanel().getBillData().setHeaderValueVO(hvo);
//	}
//	}

	@Override
	public boolean onClosing() {
//		return super.onClosing();

		return true;
	}

	//2011-7-19 Ӱ�����ص�һ��û¼�����ݣ������ж����ɱ༭�����ڲ��������ƣ���ע����
	/*@Override
	public void afterEdit(BillEditEvent e) {
		super.afterEdit(e);
		if(e.getKey().equals("ys")){
			String value=null;
			int row=e.getRow();
			if(row==0){
				value=this.getBillCardPanel().getBodyValueAt(row, "ys")==null?"":this.getBillCardPanel().getBodyValueAt(row, "ys").toString();
				if(value==null || "".equals(value) || value.length()==0){
					for(int i=row+1;i<7;i++){
						this.getBillCardPanel().getBillModel("dip_effectdef").setValueAt("", i, "ys");
						this.getBillCardPanel().getBillModel("dip_effectdef").setCellEditable(i, "ys", false);
						return;
					}
				}
			}
			if(row+1 <this.getBillCardPanel().getRowCount()){
				this.getBillCardPanel().getBillModel("dip_effectdef").setCellEditable(row+1, "ys", true);
			}
			for(int i=row+2;i<8;i++){
				value=this.getBillCardPanel().getBodyValueAt(i, "ys")==null?"":this.getBillCardPanel().getBodyValueAt(i, "ys").toString();
				if(value==null || "".equals(value) || value.length()==0){
					this.getBillCardPanel().getBillModel("dip_effectdef").setCellEditable(i, "ys", false);
				}
			}
		}
	}*/


}
