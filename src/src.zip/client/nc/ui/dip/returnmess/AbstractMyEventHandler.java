package nc.ui.dip.returnmess;

import nc.ui.trade.bill.IListController;
import nc.ui.trade.controller.IControllerBase;
import nc.ui.trade.list.BillListUI;
import nc.ui.trade.list.ListEventHandler;
import nc.ui.trade.manage.BillManageUI;
import nc.ui.trade.manage.ManageEventHandler;

/**
  *
  *������һ�������࣬��ҪĿ�������ɰ�ť�¼������Ŀ��
  *@author author
  *@version tempProject version
  */
  
  public class AbstractMyEventHandler 
                                          extends ListEventHandler{

        public AbstractMyEventHandler(BillListUI billUI, IListController control){
		super(billUI,control);		
	}
	
	protected void onBoElse(int intBtn) throws Exception {
		     	}
	
		   	
	
}