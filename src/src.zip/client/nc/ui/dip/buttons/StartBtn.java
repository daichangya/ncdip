package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class StartBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(102);
		btnVo.setBtnCode("Start");
		btnVo.setBtnName("����");
		btnVo.setBtnChinaName("����");
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
				});				
		btnVo.setChildAry(new int[]{});
		return btnVo;
	}
}
