package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class StopBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(103);
		btnVo.setBtnCode("Stop");
		btnVo.setBtnName("ֹͣ");
		btnVo.setBtnChinaName("ֹͣ");
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
        });			
		btnVo.setChildAry(new int[]{});
		return btnVo;
	}
}
