package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class EditBtn {

	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(134);
		btnVo.setBtnCode("Edit");
		btnVo.setBtnName("�޸�");
		btnVo.setBtnChinaName("�޸�");
		btnVo.setOperateStatus(
				new int[]{IBillOperate.OP_INIT,IBillOperate.OP_NOTEDIT}
				);// �����Ǹ�״̬����
		btnVo.setChildAry(new int[]{});//�����Ӱ�ť��
		return btnVo;
	}
}
