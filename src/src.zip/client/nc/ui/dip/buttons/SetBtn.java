package nc.ui.dip.buttons;


import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class SetBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(133);
		btnVo.setBtnCode("SET");
		btnVo.setBtnName("����");
		btnVo.setBtnChinaName("����");

		btnVo.setChildAry(new int[]{});//�����Ӱ�ť��
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
		});
		return btnVo;
	}

}
