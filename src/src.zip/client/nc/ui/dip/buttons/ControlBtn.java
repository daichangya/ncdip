package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class ControlBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(144);
		btnVo.setBtnCode("CONTROL");
		btnVo.setBtnName("����");
		btnVo.setBtnChinaName("����");
		btnVo.setChildAry(new int[]{});//�����Ӱ�ť��
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
		});
		return btnVo;
	}
}
