package nc.ui.dip.buttons;

import nc.vo.trade.button.ButtonVO;

public class ModelSZBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(118);
		btnVo.setBtnCode("ModelSZ");
		btnVo.setBtnName("ģ������");
		btnVo.setBtnChinaName("ģ������");
		btnVo.setChildAry(new int[]{});
		return btnVo;
	}
}
