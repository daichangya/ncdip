package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class ZHmbBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(142);
		btnVo.setBtnCode("ZHmb");
//		btnVo.setBtnName("ģ������");
		btnVo.setBtnName("ģ��");
		btnVo.setBtnChinaName("ģ��");
		btnVo.setChildAry(new int[]{});//�����Ӱ�ť��
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
		});
		return btnVo;
	}
}

