package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class ContSaveBtn {

	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(127);
		btnVo.setBtnCode("CONTSAVE");
		btnVo.setBtnName("����");
		btnVo.setBtnChinaName("����");
		btnVo.setChildAry(new int[]{});
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_EDIT,IBillOperate.OP_ADD
		});
		return btnVo;
	}
	
}
