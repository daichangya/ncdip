package nc.ui.dip.buttons;

import nc.vo.trade.button.ButtonVO;

public class DataProceBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(110);
		btnVo.setBtnCode("DataProce");
		btnVo.setBtnName("�ӹ�");
		btnVo.setBtnChinaName("�ӹ�");
		btnVo.setChildAry(new int[]{});
		return btnVo;
	}
}
