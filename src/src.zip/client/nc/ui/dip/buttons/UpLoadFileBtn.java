package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class UpLoadFileBtn {
	public final static int UpLoadFileBtn=161;
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(UpLoadFileBtn);
		btnVo.setBtnCode("UpLoadFileBtn");
		btnVo.setBtnName("�ϴ��ļ�");
		btnVo.setBtnChinaName("�ϴ��ļ�");
		btnVo.setChildAry(new int[]{});
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
		});
		return btnVo;
	}
}
