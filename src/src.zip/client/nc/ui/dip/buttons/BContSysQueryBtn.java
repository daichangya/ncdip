package nc.ui.dip.buttons;

import nc.vo.trade.button.ButtonVO;

public class BContSysQueryBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(126);
		btnVo.setBtnCode("BCONTSYSQUERY");
		btnVo.setBtnName("��ѯ");
		btnVo.setBtnChinaName("��ѯ");
		btnVo.setChildAry(new int[]{});
		return btnVo;
	}
}
