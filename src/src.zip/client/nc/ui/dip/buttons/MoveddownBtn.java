package nc.ui.dip.buttons;

import nc.vo.trade.button.ButtonVO;

public class MoveddownBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(124);
		btnVo.setBtnCode("Moveddown");
		btnVo.setBtnName("����");
		btnVo.setBtnChinaName("����");
		btnVo.setChildAry(new int[]{});
		return btnVo;
	}


}
