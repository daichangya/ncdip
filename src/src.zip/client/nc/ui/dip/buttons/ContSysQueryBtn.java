package nc.ui.dip.buttons;

import nc.vo.trade.button.ButtonVO;

public class ContSysQueryBtn {
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(125);
		btnVo.setBtnCode("CONTSYSQUERY");
		btnVo.setBtnName("ά����ѯ");
		btnVo.setBtnChinaName("ά����ѯ");
		btnVo.setChildAry(new int[]{});
		return btnVo;
	}
}
