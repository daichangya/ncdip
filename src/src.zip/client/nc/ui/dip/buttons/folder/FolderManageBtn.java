package nc.ui.dip.buttons.folder;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class FolderManageBtn {
	public final static int FOLDERMANAGE=156;
	public ButtonVO getButtonVO(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(FOLDERMANAGE);
		btnVo.setBtnCode("FolderManageBtn");
		btnVo.setBtnName("�ļ��й���");
		btnVo.setBtnChinaName("�ļ��й���");
		btnVo.setChildAry(new int[]{AddFolderBtn.ADDFOLDERBTN,EditFolderBtn.EditFolder,DeleteFolderBtn.DeleteFolder,MoveFolderBtn.MOVEFOLDERBTN});
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
		});
		return btnVo;
	}
}
