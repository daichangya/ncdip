package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class HbSet {
    public ButtonVO getBtn(){
    	ButtonVO btn=new ButtonVO();
    	btn.setBtnChinaName("��¼�ϲ�����");
    	btn.setBtnCode("HBSET");
    	btn.setBtnName("��¼�ϲ�����");
    	btn.setBtnNo(134);
    	btn.setChildAry(new int[]{});
    	btn.setOperateStatus(new int[]{
    			IBillOperate.OP_NOTEDIT
    	});
    	return btn;
    }
}
