package nc.ui.dip.buttons;

import nc.ui.trade.base.IBillOperate;
import nc.vo.trade.button.ButtonVO;

public class CredentceBtn {
	public ButtonVO getButtonVOCredence(){
		ButtonVO btnVo=new ButtonVO();
		btnVo.setBtnNo(133);
		btnVo.setBtnCode("CREDENCE");
		btnVo.setBtnName("ƾ֤�ϲ�����");
		btnVo.setBtnChinaName("ƾ֤�ϲ�����");
//		btnVo.setOperateStatus(
//				new int[]{IBillOperate.OP_INIT,IBillOperate.OP_NOTEDIT}
//				);// �����Ǹ�״̬����
		btnVo.setChildAry(new int[]{});//�����Ӱ�ť��
		btnVo.setOperateStatus(new int[]{
				IBillOperate.OP_NOTEDIT
		});
		return btnVo;
	}
}
