package nc.ui.dip.datasynch;

import java.util.Hashtable;


/**
 *
 *�����ҵ�������
 *
 * @author author
 * @version tempProject version
 */
public abstract class AbstractMyDelegator extends nc.ui.trade.bsdelegate.BDBusinessDelegator {

	public Hashtable loadChildDataAry(String[] tableCodes,String key) 
	                                                 throws Exception{
		
		
	   Hashtable dataHashTable = new Hashtable();
	   nc.vo.dip.datasynch.DipDatasynchVO[] bodyVOs1=
		   (nc.vo.dip.datasynch.DipDatasynchVO[])queryByCondition(nc.vo.dip.datasynch.DipDatasynchVO.class,
				   getBodyCondition(nc.vo.dip.datasynch.DipDatasynchVO.class,key));
	   if(bodyVOs1!=null&&bodyVOs1.length>0){
		   dataHashTable.put("pk_datasynch", bodyVOs1);
	   }
	              	   return dataHashTable;
		
	}
	
	
       /**
         *
         *�÷������ڻ�ȡ��ѯ�������û���ȱʡʵ���п��ԶԸ÷��������޸ġ�
         *
         */	
       public String getBodyCondition(Class bodyClass,String key){
		
       		if(bodyClass==nc.vo.dip.datasynch.DipDatasynchVO.class);
       		return "pk_datasynch='"+key+"' and isnull(dr,0)=0";
	 
       } 
	
}
