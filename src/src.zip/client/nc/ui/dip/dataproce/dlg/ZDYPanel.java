package nc.ui.dip.dataproce.dlg;


import javax.swing.WindowConstants;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class ZDYPanel extends javax.swing.JPanel {
	private JScrollPane jScrollPane1;
	private JPanel jPanel1;
	private JLabel jLabel1;
	private JPanel jPanel2;
	private JScrollPane jScrollPane2;

	/**
	* Auto-generated main method to display this 
	* JPanel inside a new JFrame.
	*/
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.getContentPane().add(new ZDYPanel());
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
	
	public ZDYPanel() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			this.setPreferredSize(new java.awt.Dimension(676, 421));
			this.setLayout(null);
			{
				jScrollPane1 = new JScrollPane();
				this.add(jScrollPane1);
				jScrollPane1.setBounds(0, 39, 227, 382);
			}
			{
				jScrollPane2 = new JScrollPane();
				this.add(jScrollPane2);
				jScrollPane2.setBounds(233, 39, 443, 262);
			}
			{
				jPanel1 = new JPanel();
				this.add(jPanel1);
				jPanel1.setBounds(233, 308, 438, 32);
			}
			{
				jPanel2 = new JPanel();
				this.add(jPanel2);
				jPanel2.setBounds(0, 0, 431, 33);
			}
			{
				jLabel1 = new JLabel();
				this.add(jLabel1);
				jLabel1.setText("jLabel1");
				jLabel1.setBounds(233, 352, 443, 69);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
