package nc.ui.dip.contdatawh;

import nc.ui.dip.buttons.IBtnDefine;
import nc.ui.trade.bill.ICardController;
import nc.ui.trade.button.IBillButton;
import nc.ui.trade.treemanage.BillTreeManageUI;
import nc.ui.trade.treemanage.TreeManageEventHandler;

/**
 *
 *������һ�������࣬��ҪĿ�������ɰ�ť�¼������Ŀ��
 *@author author
 *@version tempProject version
 */

public class AbstractMyEventHandler 
extends TreeManageEventHandler  {

	public AbstractMyEventHandler(BillTreeManageUI  billUI, ICardController control){
		super(billUI,control);		
	}

	protected void onBoElse(int intBtn) throws Exception {
		switch (intBtn) {
		case IBtnDefine.CONTSYSQUERY:
			onContsysQuery(intBtn);
			break;
		case IBtnDefine.BCONTSYSQUERY:
			onBContsysQuery(intBtn);
			break;
		case IBtnDefine.CONTSAVE:
			onContSave(intBtn);
			break;
		case IBillButton.ExportBill:
			onExportBill(intBtn);
			break;
		case IBtnDefine.DATACLEAR:
			onDataClear(intBtn);
			break;
		case IBtnDefine.contresut:
			contResut(intBtn);
			break;
		case IBtnDefine.edit:
			edit(intBtn);
			break;
		//2011-6-10 У����
		case IBtnDefine.VALIDATECHECK:
			
			onDataCheck();
			break;
		case 
		IBtnDefine.SET:
			onBoSet();
			break;
		case
		IBtnDefine.DATACHECK:
			validateCheck(intBtn);
			break;
			
			
		}
			
		
	}
	
	
		
	protected void onBoSet() {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @desc ��������
	 * */
	protected void onDataClear(int intBtn)throws Exception{}
	/**
	 * @desc ����ϵͳ��ѯ����
	 * @author fjf
	 * */
	protected void onContsysQuery(int intBtn) throws Exception{};
	/**
	 * @desc ������ϵͳ��ѯ����
	 * @author fjf
	 * */
	protected void onBContsysQuery(int intBtn) throws Exception{};
	/**
	 * @desc ����
	 * @author fjf
	 * */
	protected void onContSave(int intBtn) throws Exception{};
	/**
	 * @desc ����
	 * */
	protected void onExportBill(int intBtn) throws Exception{};
	/**
	 * ���ս��
	 * */
	protected void contResut(int intBtn) throws Exception{};
	/**
	 * �޸�
	 * */
	protected void edit(int intBtn) throws Exception{};
	
	/**
	 * @desc У����
	 * @author cl
	 * @date 2011-6-10
	 */
	protected void validateCheck(int intBtn) throws Exception{};

	
	/**
	 * ����У����
	 * @param intBtn
	 * @throws Exception
	 * @author lyz
	 */
	protected void onDataCheck() throws Exception{}
}