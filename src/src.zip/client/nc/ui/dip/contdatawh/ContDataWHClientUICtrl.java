package nc.ui.dip.contdatawh;

import nc.ui.dip.buttons.IBtnDefine;
import nc.ui.trade.businessaction.IBusinessActionType;

import nc.ui.trade.button.IBillButton;
import nc.ui.trade.treemanage.AbstractTreeManageController;
import nc.vo.dip.contdatawh.ContdatawhBVO;
import nc.vo.dip.contdatawh.ContdatawhHVO;
import nc.vo.dip.contdatawh.MyBillVO;

/**
 * <b> �ڴ˴���Ҫ��������Ĺ��� </b>
 *
 * <p>
 *     �ڴ˴����Ӵ����������Ϣ
 * </p>
 *
 * Create on 2006-4-6 16:00:51
 *
 * @author authorName
 * @version tempProject version
 */

public class ContDataWHClientUICtrl extends AbstractTreeManageController {

	public String[] getCardBodyHideCol() {
		return null;
	}

	public int[] getCardButtonAry() {

		return new int[]{
				IBillButton.Query,

//				IBillButton.Add,
//				IBillButton.Edit,
//				IBillButton.Save,
				IBillButton.Cancel,
				IBillButton.Refresh,
//				IBillButton.Delete,
//				IBillButton.Line,
//				IBillButton.Return,
//				IBillButton.ImportBill,
//				IBillButton.ExportBill,
//				IBtnDefine.VALIDATECHECK,
//				IBtnDefine.DATACLEAR,
//				IBtnDefine.EXPORTMODEL

//				IBillButton.Add,
//				IBillButton.Edit,
//				IBillButton.Save,
//				IBillButton.Cancel,
//				IBillButton.Delete,
//				IBillButton.Line,
//				IBillButton.Return,
//				IBillButton.ImportBill,
//				IBillButton.ExportBill,
//				IBtnDefine.VALIDATECHECK,
//				IBtnDefine.DATACLEAR,
//				IBtnDefine.EXPORTMODEL,
//				IBtnDefine.CONTSYSQUERY,
//				IBtnDefine.BCONTSYSQUERY

		};

	}

	public int[] getListButtonAry() {		
		return new int[]{
//				IBillButton.Query,
				IBillButton.Refresh,
				IBtnDefine.SET,
				IBtnDefine.BCONTSYSQUERY,
				IBtnDefine.edit,
				IBtnDefine.CONTSYSQUERY,
				
				IBtnDefine.CONTSAVE,
//				IBillButton.Add,
//				IBillButton.Edit,
//				IBillButton.Save,
				IBillButton.Cancel,
//				IBillButton.Delete,
//				IBillButton.Line,
//				IBillButton.Card,
				IBillButton.ImportBill,
				IBillButton.ExportBill,
				//2011-6-10 У����
				IBtnDefine.DATACLEAR,
				IBtnDefine.VALIDATECHECK,
//				IBtnDefine.EXPORTMODEL,
//				IBtnDefine.contresut,
				IBtnDefine.DATACHECK

		};

	}

	public boolean isShowCardRowNo() {
		return true;
	}

	public boolean isShowCardTotal() {
		return false;
	}

	public String getBillType() {
		return "H4H3H4H1";
	}

	public String[] getBillVoName() {
		return new String[]{
				MyBillVO.class.getName(),
				ContdatawhHVO.class.getName(),

				ContdatawhHVO.class.getName()
		};
	}

	public String getBodyCondition() {
		return null;
	}

	public String getBodyZYXKey() {
		return null;
	}

	public int getBusinessActionType() {
//		return IBusinessActionType.BD;
		return IBusinessActionType.PLATFORM;
	}

	public String getChildPkField() {
		return null;
	}

	public String getHeadZYXKey() {
		return null;
	}

	public String getPkField() {
		return null;
	}

	public Boolean isEditInGoing() throws Exception {
		return null;
	}

	public boolean isExistBillStatus() {
		return false;
	}

	public boolean isLoadCardFormula() {		
		return false;
	}

	public String[] getListBodyHideCol() {	
		return null;
	}

	public String[] getListHeadHideCol() {		
		return null;
	}

	public boolean isShowListRowNo() {		
		return false;
	}

	public boolean isShowListTotal() {
		return false;
	}

	/**
	 * �Ƿ񵥱�
	 * @return boolean true:�����壬false:����ͷ
	 */ 
//	public boolean isSingleDetail() {
//		return false; 
//	}

	/**
	 * 2011-4-11 chengli
	 */
	public boolean isAutoManageTree() {
		return true;
	}
//	public boolean isChildTree() {
//		return false;
//	}

	public boolean isTableTree() {
		return false;
	}
}
