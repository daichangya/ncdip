package nc.ui.dip.managerserver;

import nc.ui.dip.managerserver.AbstractManagServerClientUI;
import nc.ui.dip.managerserver.MyEventHandler;
import nc.ui.trade.list.ListEventHandler;


/**
 * <b> �ڴ˴���Ҫ��������Ĺ��� </b>
 *
 * <p>
 *     �ڴ˴����Ӵ����������Ϣ
 * </p>
 *
 *
 * @author author
 * @version tempProject version
 */
 public class ManagServerClientUI extends AbstractManagServerClientUI{
	 public ManagServerClientUI(){
		 super();
		 try {
			((MyEventHandler)this.getListEventHandler()).onBoQuery();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
       
       @Override
	protected ListEventHandler createEventHandler() {
		// TODO Auto-generated method stub
		return new MyEventHandler(this,getUIControl());
	}

	public String getRefBillType() {
   		return null;
   	}
//	public void setBodySpecialData(CircularlyAccessibleValueObject[] vos)
//			throws Exception {}
//
//	protected void setHeadSpecialData(CircularlyAccessibleValueObject vo,
//			int intRow) throws Exception {}
//
//	protected void setTotalHeadSpecialData(CircularlyAccessibleValueObject[] vos)
//			throws Exception {	}

       /**
   	 * �޸Ĵ˷�����ʼ��ģ��ؼ�����
   	 */
	protected void initSelfData() {	}

	public void setDefaultData() throws Exception {
	}
	


}
